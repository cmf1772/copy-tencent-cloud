<template>
  <div class="wrapper">
    公交车
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>