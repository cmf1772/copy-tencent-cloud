<template>
  <div class="wrapper">
    顺风车
  </div>
</template>

<script>
export default {
  created(){
    this.$router.push({
      path:"/serve/travel/free_ride"
    })
  }
}
</script>

<style>

</style>