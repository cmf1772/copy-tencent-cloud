<template>
  <div class="main">success</div>
</template>

<script>
export default {

}
</script>

<style>

</style>