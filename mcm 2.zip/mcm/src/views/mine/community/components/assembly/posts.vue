<template>
  <div class="wrapper">
    <div class="list">
      <div class="item" @click="postsDetailed">
        <div class="title">
          <span>记录不一样的元宵节</span>
          <van-icon name="ellipsis" size=".28rem" />
        </div>
        <div class="img-view">
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
        </div>
        <div class="tip">
          <div>#随手拍北京</div>
        </div>
        <div class="footer">
          <div class="time">22分钟前</div>
          <ul>
            <li>
              <span>
                <img src="@/assets/images/icon/fenxiang.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/speak.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/ding.png" alt />
              </span>
            </li>
          </ul>
        </div>
      </div>
      <div class="item" @click="postsDetailed">
        <div class="title">
          <span>记录不一样的元宵节</span>
          <van-icon name="ellipsis" size=".28rem" />
        </div>
        <div class="img-view">
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
        </div>
        <div class="tip">
          <div>#随手拍北京</div>
          <div>#随手拍南京</div>
        </div>
        <div class="footer">
          <div class="time">22分钟前</div>
          <ul>
            <li>
              <span>
                <img src="@/assets/images/icon/fenxiang.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/speak.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/ding.png" alt />
              </span>
            </li>
          </ul>
        </div>
      </div>
      <div class="item" @click="postsDetailed">
        <div class="title">
          <span>记录不一样的元宵节</span>
          <van-icon name="ellipsis" size=".28rem" />
        </div>
        <div class="img-view" :style="`grid-template-columns: repeat(1, 1fr);`">
          <img style="height:3.43rem" src="@/assets/images/index/banner1.jpg" />
        </div>
        <div class="tip">
          <div>#随手拍北京</div>
          <div>#随手拍南京</div>
        </div>
        <div class="footer">
          <div class="time">22分钟前</div>
          <ul>
            <li>
              <span>
                <img src="@/assets/images/icon/fenxiang.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/speak.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/ding.png" alt />
              </span>
            </li>
          </ul>
        </div>
      </div>
      <div class="item" @click="postsDetailed">
        <div class="title">
          <span>记录不一样的元宵节</span>
          <van-icon name="ellipsis" size=".28rem" />
        </div>
        <div class="img-view">
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
        </div>
        <div class="tip">
          <div>#随手拍北京</div>
          <div>#随手拍南京</div>
        </div>
        <div class="footer">
          <div class="time">22分钟前</div>
          <ul>
            <li>
              <span>
                <img src="@/assets/images/icon/fenxiang.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/speak.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/ding.png" alt />
              </span>
            </li>
          </ul>
        </div>
      </div>
      <div class="item" @click="postsDetailed">
        <div class="title">
          <span>记录不一样的元宵节</span>
          <van-icon name="ellipsis" size=".28rem" />
        </div>
        <div class="img-view" :style="`grid-template-columns: repeat(1, 1fr);`">
          <img style="height:3.43rem" src="@/assets/images/index/banner1.jpg" />
        </div>
        <div class="tip">
          <div>#随手拍北京</div>
          <div>#随手拍南京</div>
        </div>
        <div class="footer">
          <div class="time">22分钟前</div>
          <ul>
            <li>
              <span>
                <img src="@/assets/images/icon/fenxiang.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/speak.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/ding.png" alt />
              </span>
            </li>
          </ul>
        </div>
      </div>
      <div class="item" @click="postsDetailed">
        <div class="title">
          <span>记录不一样的元宵节</span>
          <van-icon name="ellipsis" size=".28rem" />
        </div>
        <div class="img-view">
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
        </div>
        <div class="tip">
          <div>#随手拍北京</div>
        </div>
        <div class="footer">
          <div class="time">22分钟前</div>
          <ul>
            <li>
              <span>
                <img src="@/assets/images/icon/fenxiang.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/speak.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/ding.png" alt />
              </span>
            </li>
          </ul>
        </div>
      </div>
      <div class="item" @click="postsDetailed">
        <div class="title">
          <span>记录不一样的元宵节</span>
          <van-icon name="ellipsis" size=".28rem" />
        </div>
        <div class="img-view">
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
          <img src="@/assets/images/index/banner1.jpg" />
        </div>
        <div class="tip">
          <div>#随手拍北京</div>
          <div>#随手拍南京</div>
        </div>
        <div class="footer">
          <div class="time">22分钟前</div>
          <ul>
            <li>
              <span>
                <img src="@/assets/images/icon/fenxiang.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/speak.png" alt />
              </span>
            </li>
            <li>
              <span>
                <img src="@/assets/images/icon/ding.png" alt />
              </span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  methods: {
    postsDetailed() {
      this.$router.push({
        path: "/mine/community/posts/detailed"
      });
    }
  }
};
</script>

<style lang="less" scoped>
.wrapper {
  padding: 0.3rem 0;
  .list {
    .item:not(:last-child) {
      padding-bottom: 0.45rem;
      border-bottom: 1px solid #eee;
    }
    .item:not(:first-child) {
      padding-top: 0.45rem;
    }
    .item {
      .footer {
        display: flex;
        padding: 0.3rem 0;
        font-size: 0.26rem;
        color: #999;
        .time {
          flex: 1;
          font-size: 0.24rem;
        }
        ul {
          width: 40%;
          display: flex;
          justify-content: space-around;
          span {
            display: flex;
            align-items: center;
          }
          img {
            width: 0.3rem;
          }
        }
      }
      .tip {
        padding-bottom: 0.2rem;
        display: flex;
        div {
          padding: 0.1rem 0.2rem;
          color: #bcbcbc;
          font-size: 0.24rem;
          background: #f7f7f7;
          border-radius: 1rem;
          margin-right: 0.1rem;
        }
      }
      .img-view {
        padding: 0.3rem 0;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        grid-gap: 0.1rem;
        img {
          width: 100%;
          height: 2.12rem;
          border-radius: 0.05rem;
        }
      }
      .title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        span {
          font-size: 0.3rem;
        }
        .van-icon {
          transform: rotate(90deg);
        }
      }
    }
  }
}
</style>