<template>
  <div class="container">
    卖出
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>