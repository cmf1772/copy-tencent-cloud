<template>
  <div class="wrapper">
    有图
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>