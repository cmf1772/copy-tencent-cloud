<template>
  <div class="wrapper">
    <div class="list">
      <div class="item">
        <div class="title">
          生活、出行、健康等
          <van-icon name="arrow" size=".38rem" />
        </div>
        <div class="wrap-item">
          <div class="item-value">
            <div class="value">
              <div class="card yellow">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>电子公交卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>买车养车更省钱</p>
                <span>太平洋4S折扣卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card white">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>电子公交卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>买车养车更省钱</p>
                <span>太平洋4S折扣卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card blue">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>电子公交卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>买车养车更省钱</p>
                <span>太平洋4S折扣卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card blue">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>电子公交卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>买车养车更省钱</p>
                <span>太平洋4S折扣卡</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="item">
        <div class="title">
          购物、服饰、超市等
          <van-icon name="arrow" size=".38rem" />
        </div>
        <div class="wrap-item">
          <div class="item-value">
            <div class="value">
              <div class="card white">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>优衣库会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>服饰人生 优享生活</p>
                <span>优衣库会员卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card yellow">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>优衣库会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>服饰人生 优享生活</p>
                <span>优衣库会员卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card blue">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>优衣库会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>服饰人生 优享生活</p>
                <span>优衣库会员卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card black">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>优衣库会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>服饰人生 优享生活</p>
                <span>优衣库会员卡</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="item">
        <div class="title">
          美食、餐饮、零食等
          <van-icon name="arrow" size=".38rem" />
        </div>
        <div class="wrap-item">
          <div class="item-value">
            <div class="value">
              <div class="card white">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>汉堡王会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>1元霸王鸡条</p>
                <span>汉堡王会员卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card yellow">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>汉堡王会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>1元霸王鸡条</p>
                <span>汉堡王会员卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card blue">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>汉堡王会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>1元霸王鸡条</p>
                <span>汉堡王会员卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card black">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>汉堡王会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>1元霸王鸡条</p>
                <span>汉堡王会员卡</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="item">
        <div class="title">
          娱乐、酒店、旅游等
          <van-icon name="arrow" size=".38rem" />
        </div>
        <div class="wrap-item">
          <div class="item-value">
            <div class="value">
              <div class="card yellow">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>网鱼网咖会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>网吧会员专享</p>
                <span>网鱼网咖会员卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card blue">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>网鱼网咖会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>网吧会员专享</p>
                <span>网鱼网咖会员卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card blue">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>网鱼网咖会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>网吧会员专享</p>
                <span>网鱼网咖会员卡</span>
              </div>
            </div>
          </div>
          <div class="item-value">
            <div class="value">
              <div class="card black">
                <div class="center">
                  <div class="icon">
                    <img src="@/assets/images/index/banner1.jpg" />
                  </div>
                  <div class="name">
                    <span>网鱼网咖会员卡</span>
                  </div>
                </div>
              </div>
              <div class="foot">
                <p>网吧会员专享</p>
                <span>网鱼网咖会员卡</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="less" scoped>
.wrapper {
  .btn {
    display: flex;
    justify-content: center;
    margin-bottom: 0.5rem;
    .van-button {
      width: 4rem;
    }
  }
  .title {
    font-size: 0.42rem;
    margin: 0.3rem 0;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .item {
    margin-bottom: 0.8rem;
    .wrap-item {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      grid-gap: 0.36rem;
    }
    .foot {
      padding: 0.1rem 0 0rem 0;
      p {
        font-size: 0.3rem;
      }
      span {
        font-size: 0.24rem;
        display: block;
        color: #777;
        margin-top: 0.05rem;
      }
    }
    .value {
      display: flex;
      flex-direction: column;
      .card {
        height: 1.3rem;
        display: flex;
        align-items: flex-start;
        // background: skyblue;
        background-size: 107% 113%;
        padding: 0.35rem;
        background-position: center center;
        overflow: hidden;
        box-shadow: 0 0 10px 1px #eee;
        border-radius: 0.1rem;
        padding: 0.2rem;
        color: #fff;
        .center {
          display: flex;
          align-items: center;
        }
        .name {
          padding-left: 0.1rem;
          display: flex;
          flex-direction: column;
          justify-content: center;
          span {
            font-size: 0.26rem;
          }
        }
        .icon {
          border-radius: 1rem;
          box-sizing: border-box;
          border: 2px solid #fff;
          overflow: hidden;
          width: 0.6rem;
          height: 0.6rem;
          display: flex;
          align-items: flex-start;
          img {
            width: 100%;
            height: 100%;
          }
        }
      }
    }
  }

  .white {
    background: url(../../../../assets/images/icon/mine/vip/white.png);
  }
  .blue {
    background: url(../../../../assets/images/icon/mine/vip/blue.png);
  }
  .black {
    background: url(../../../../assets/images/icon/mine/vip/black.png);
  }
  .yellow {
    background: url(../../../../assets/images/icon/mine/vip/yellow.png);
  }
}
</style>