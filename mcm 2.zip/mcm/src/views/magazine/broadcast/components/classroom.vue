<template>
  <div>课堂</div>
</template>

<script>
export default {

}
</script>

<style>

</style>