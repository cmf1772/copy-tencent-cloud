// actions 异步操作
export default {
  // async getAddress ({commit, state}) {
  //   const geohash = state.latitude + ',' + state.longitude
  //   const res = await reqAddress(geohash)
  //   if (res.code === 0) {
  //     const address = res.data
  //     commit('getAddress', {address})
  //   }
  // }
}
