import wx from 'weixin-js-sdk'
export const wxshare = {
    install: (Vue, msg) => {
        
    }
}