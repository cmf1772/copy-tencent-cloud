// 导入自己需要的组件
import { Dropdown  } from 'element-ui'
const element = {
  install: function (Vue) {
    Vue.use(Dropdown)
  }
}
export default element