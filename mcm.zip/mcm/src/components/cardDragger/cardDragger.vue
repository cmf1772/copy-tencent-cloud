<template>
  <div class="cardDragger">
    1

  </div>
</template>

<script>
export default {
  name: 'cardDragger',
  props: ['cardList']
}
</script>

<style lang="scss" scoped>
.cardDragger {
  font-size: 0.25rem;
}
</style>