<template>
  <div class="main">
    动漫
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>