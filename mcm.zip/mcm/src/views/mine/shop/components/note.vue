<template>
  <div class="wrapper">
    <div class="list">
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
      <div class="item" @click="detailed">
        <div class="img">
          <img
            src="@/assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg"
          />
        </div>
        <div class="title">
          AFV情人节联名款春秋印花
          短袖T恤印花短袖T恤印花短袖T恤印花短袖T恤印花短袖
        </div>
        <div class="user">
          <div class="left">
            <div class="icon">
              <img src="@/assets/images/user.png" />
            </div>
            <div class="name">默默大师</div>
          </div>
          <div class="like">
            <van-icon name="like-o" size=".26rem" color="#777" />3600
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    detailed() {
      this.$router.push({
        path: "/mine/small_shop/note/detailed"
      });
    }
  }
};
</script>
<style lang="less" scoped>
.wrapper {
  padding-bottom: 0.5rem;
  .list {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.31rem;
    .item {
      display: flex;
      flex-direction: column;
      .img {
        img {
          width: 100%;
          height: auto;
          border-radius: 0.03rem;
        }
      }
      .title {
        margin: 0.1rem 0;
        font-size: 0.27rem;
        margin-top: 0.27rem;
        display: -webkit-box;
        overflow: hidden;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        text-overflow: ellipsis;
      }
      .user {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.15rem 0;
        padding-bottom: 0;
        .left {
          display: flex;
          align-items: center;
          .icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 0.4rem;
            margin-right: 0.05rem;
            height: 0.4rem;
            // border-radius: 1rem;
            overflow: hidden;
            img {
              width: 100%;
              height: 100%;
            }
          }
          .name {
            font-size: 0.2rem;
            margin-left: 0.05rem;
            color: #777;
          }
        }
        .like {
          display: flex;
          align-items: center;
          font-size: 0.2rem;
          color: #777;
          .van-icon{
            margin-right: 0.05rem;
          }
        }
      }
    }
  }
}
</style>