<template>
  <div class="main">
    <pub-head></pub-head>
    <div class="container">
      照片
    </div>
    <pub-foot></pub-foot>
  </div>
</template>

<script>
import pubHead from "./components/publichead"
import pubFoot from "./components/publicfoot"
export default {
  components:{pubHead,pubFoot}
}
</script>

<style>

</style>