<template>
  <div class="container">
    
  </div>
</template>

<script>
export default {};
</script>

<style lang="less" scoped>

// 主体
.container {
  position: absolute;
  left: 0;
  bottom: 0;
  top: 0;
  right: 0;
    background: url("../../../../assets/images/magazine/dynamic/65aa3d98affd202bf958ed1fc0f3361632544f4dc574-OOkVsF_fw658.jpg");
  background-size: 100% 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: calc(49px + 0.4rem);
}
</style>