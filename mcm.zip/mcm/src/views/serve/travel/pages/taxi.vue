<template>
  <div class="wrapper">
    出租车
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>