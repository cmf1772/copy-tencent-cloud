<template>
  <div class="main">pay</div>
</template>

<script>
export default {

}
</script>

<style>

</style>