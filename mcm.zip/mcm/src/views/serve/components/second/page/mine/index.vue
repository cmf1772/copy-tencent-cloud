<template>
  <div class="main">
    我的
    <pFooter></pFooter>
  </div>
</template>

<script>
import pFooter from '../../components/public_footer';
export default {
  components:{pFooter}
}
</script>

<style>

</style>